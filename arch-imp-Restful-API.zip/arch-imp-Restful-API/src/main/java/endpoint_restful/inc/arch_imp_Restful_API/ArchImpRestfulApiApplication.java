package endpoint_restful.inc.arch_imp_Restful_API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchImpRestfulApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchImpRestfulApiApplication.class, args);
	}

}
