package endpoint_restful.inc.arch_imp_Restful_API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchImpRestfulApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
